<?php

namespace App\Http\Controllers;

use App\Alumnos;
use Illuminate\Http\Request;

use App\Http\Requests;

class PageController extends Controller
{
    public function home()
    {
        return view('inicio');
    }
    public  function  add()
    {
        return view('add');
    }
    public  function  newadd()
    {
        $data = request()->all();
        Alumnos::create($data);
        return redirect()->to('/');
    }
    public function listalumnos()
    {
        $alumno = Alumnos::all();
        $users = Alumnos::paginate(11);
        return view('/list', compact('alumno','users'));


    }
    public function edit($id)
    {
        $alumnos = Alumnos::find($id);
        return view('/edit/alumnos', compact('alumnos'));
    }
    public function update($id)
    {
        $this->validate(request(), [
            'name' => ['required', 'max:10']

        ]);
        $alumnos = Alumnos::find($id);
        $alumnos->fill(request()->all());
        $alumnos->save();
        return redirect()->to('/list');
    }
    public function destroy($id)
    {
        $data = Alumnos::find($id);
        $data->delete();
        return redirect()->to('/list');


    }



}
