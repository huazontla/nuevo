<?php

/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

#Route::get('/', function () {
 #   return view('welcome');
#});

Route::get('/inicio', 'PageController@home');
Route::get('/add', 'PageController@add');
Route::post('/add', 'PageController@newadd');
Route::get('/list', 'PageController@listalumnos');
Route::get('/edit/{id}', 'PageController@edit');
Route::get('/edit/alumno/{id}', 'PageController@update');
Route::get('/edit/delete/{id}', 'PageController@destroy');




/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| This route group applies the "web" middleware group to every route
| it contains. The "web" middleware group is defined in your HTTP
| kernel and includes session state, CSRF protection, and more.
|
*/

#Route::group(['middleware' => ['web']], function () {
 #   //
#});

Route::group(['middleware' => 'web'], function () {
    Route::auth();

    Route::get('/home', 'HomeController@index');
});

Route::group(['middleware' => 'web'], function () {
    Route::auth();

    Route::get('/home', 'HomeController@index');
});
