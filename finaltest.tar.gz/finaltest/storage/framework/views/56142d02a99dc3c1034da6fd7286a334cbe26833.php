<?php $__env->startSection('titleMessage'); ?>Alumnos@endsection

<?php $__env->startSection('sectionMessae'); ?>Lista de Alumnos <?php $__env->stopSection(); ?>

<?php $__env->startSection('list'); ?>

    <table class="table table-responsive ">
        <thead>
        <th>ID</th><th>NOMBRE</th><th>APELLIDOS</th><th>GENERO</th><th>EDAD</th><th>CURP</th><th>GRADO</th><th>GRUPO</th><th>ACCIONES</th>
        </thead>
        <tbody>
            <?php foreach($alumno as $alumno): ?>
        <tr>
            <td><?php echo e($alumno->id); ?></td><td><?php echo e($alumno->name); ?></td><td><?php echo e($alumno->lastn); ?></td><td><?php echo e($alumno->gender); ?></td><td><?php echo e($alumno->age); ?></td><td><?php echo e($alumno->age); ?></td><td><?php echo e($alumno->curp); ?></td><td><?php echo e($alumno->grade); ?></td><td><?php echo e($alumno->group); ?></td><td>
                <a href="edit/<?php echo e($alumno->id); ?>" class="btn btn-warning">Editar</a></td>
        </tr>
             <?php endforeach; ?>
        </tbody>
    </table>

    <div class="pagination"> <?php echo e($users->links()); ?>



    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>