<?php $__env->startSection('form'); ?>

    <div class="panel panel-default">
        <div class="panel panel-heading">Agregar Nuevo Alumno !</div>
        <form action="/add" method="POST" class="form">
            {<?php echo csrf_field(); ?>}
            <div class="form-group">
                <input type="text" class="form-control" name="name" placeholder="Nombre Alumno">

            </div>
            <div class="form-group">
                <input type="text" class="form-control" name="lastn" placeholder="Apellidos">

            </div>
            <div class="form-group">
                <select name="gender" id="" class="form-control">
                    <option value="">Genero</option>
                    <option value="Masculino">Masculino</option>
                    <option value="Femenino">Femenino</option>
                </select>

            </div>
            <div class="form-group">
                <input type="text" class="form-control" name="age" placeholder="Edad">

            </div>
            <div class="form-group">
                <input type="text" class="form-control" name="curp" placeholder="curp">

            </div>
            <div class="form-group">
                <select name="grade" id="" class="form-control">
                    <option value="">Grade</option>
                    <option value="1°">1°</option>
                    <option value="2°">2°</option>
                    <option value="3°">3°</option>
                </select>

            </div>
            <div class="form-group">
                <select name="group" id="" class="form-control">
                    <option value="">Grupo</option>
                    <option value="A">A</option>
                    <option value="B">B</option>
                </select>

            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-success">Guardar</button>
            </div>
        </form>
    </div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>