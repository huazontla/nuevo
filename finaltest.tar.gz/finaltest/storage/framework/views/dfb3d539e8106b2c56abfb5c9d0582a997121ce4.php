<?php $__env->startSection('formedit'); ?>

    <div class="panel panel-default">
        <div class="panel panel-heading">Agregar Nuevo Alumno !</div>
        <form action="/edit/alumno/<?php echo e($alumnos->id); ?>" method="PATCH" class="form">

            <div class="form-group">
                <label for="">Nombre</label>
                <input type="text" class="form-control" name="name" value="<?php echo e($alumnos->name); ?>" required>

            </div>
            <div class="form-group">
                <label for="">Apellidos</label>
                <input type="text" class="form-control" name="lastn" value="<?php echo e($alumnos->lastn); ?>">

            </div>
            <div class="form-group">
                <label for="">Genero</label>
                <select name="gender" id="" class="form-control" >
                    <option value=""><?php echo e($alumnos->gender); ?></option>
                    <option value="Masculino">Masculino</option>
                    <option value="Femenino">Femenino</option>
                </select>

            </div>
            <div class="form-group">
                <label for="">Edad</label>
                <input type="text" class="form-control" name="age" value="<?php echo e($alumnos->age); ?>">

            </div>
            <div class="form-group">
                <label for="">Curp</label>
                <input type="text" class="form-control" name="curp" value="<?php echo e($alumnos->curp); ?>">

            </div>
            <div class="form-group">
                <label for="">Grado</label>
                <select name="grade" id="" class="form-control">
                    <option value=""><?php echo e($alumnos->grade); ?></option>
                    <option value="1°">1°</option>
                    <option value="2°">2°</option>
                    <option value="3°">3°</option>
                </select>

            </div>
            <div class="form-group">
                <label for="">Grupo</label>
                <select name="group" id="" class="form-control">
                    <option value=""><?php echo e($alumnos->group); ?></option>
                    <option value="A">A</option>
                    <option value="B">B</option>
                </select>

            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary">Actualizar</button>





            </div>
        </form>

        <form action="/edit/delete/<?php echo e($alumnos->id); ?>"  method="DELETE" >
            <div class="form-group">
                <hr>
                <button type="submit" class="btn btn-danger " >Eliminar !</button>
            </div>

        </form>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>