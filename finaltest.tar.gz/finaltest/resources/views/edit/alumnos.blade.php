@extends('layout')

@section('formedit')

    <div class="panel panel-default">
        <div class="panel panel-heading">Agregar Nuevo Alumno !</div>
        <form action="/edit/alumno/{{ $alumnos->id }}" method="PATCH" class="form">

            <div class="form-group">
                <label for="">Nombre</label>
                <input type="text" class="form-control" name="name" value="{{ $alumnos->name }}" required>

            </div>
            <div class="form-group">
                <label for="">Apellidos</label>
                <input type="text" class="form-control" name="lastn" value="{{ $alumnos->lastn }}">

            </div>
            <div class="form-group">
                <label for="">Genero</label>
                <select name="gender" id="" class="form-control" >
                    <option value="">{{ $alumnos->gender }}</option>
                    <option value="Masculino">Masculino</option>
                    <option value="Femenino">Femenino</option>
                </select>

            </div>
            <div class="form-group">
                <label for="">Edad</label>
                <input type="text" class="form-control" name="age" value="{{ $alumnos->age }}">

            </div>
            <div class="form-group">
                <label for="">Curp</label>
                <input type="text" class="form-control" name="curp" value="{{ $alumnos->curp }}">

            </div>
            <div class="form-group">
                <label for="">Grado</label>
                <select name="grade" id="" class="form-control">
                    <option value="">{{ $alumnos->grade }}</option>
                    <option value="1°">1°</option>
                    <option value="2°">2°</option>
                    <option value="3°">3°</option>
                </select>

            </div>
            <div class="form-group">
                <label for="">Grupo</label>
                <select name="group" id="" class="form-control">
                    <option value="">{{ $alumnos->group }}</option>
                    <option value="A">A</option>
                    <option value="B">B</option>
                </select>

            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary">Actualizar</button>





            </div>
        </form>

        <form action="/edit/delete/{{ $alumnos->id }}"  method="DELETE" >
            <div class="form-group">
                <hr>
                <button type="submit" class="btn btn-danger " >Eliminar !</button>
            </div>

        </form>
    </div>

    @endsection