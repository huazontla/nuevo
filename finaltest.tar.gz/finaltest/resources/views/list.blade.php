@extends('layout')

@section('titleMessage')Alumnos@endsection

@section('sectionMessae')Lista de Alumnos @endsection

@section('list')

    <table class="table table-responsive ">
        <thead>
        <th>ID</th><th>NOMBRE</th><th>APELLIDOS</th><th>GENERO</th><th>EDAD</th><th>CURP</th><th>GRADO</th><th>GRUPO</th><th>ACCIONES</th>
        </thead>
        <tbody>
            @foreach($alumno as $alumno)
        <tr>
            <td>{{ $alumno->id }}</td><td>{{ $alumno->name }}</td><td>{{ $alumno->lastn }}</td><td>{{ $alumno->gender }}</td><td>{{ $alumno->age }}</td><td>{{ $alumno->age }}</td><td>{{ $alumno->curp }}</td><td>{{ $alumno->grade }}</td><td>{{ $alumno->group }}</td><td>
                <a href="edit/{{ $alumno->id }}" class="btn btn-warning">Editar</a></td>
        </tr>
             @endforeach
        </tbody>
    </table>

    <div class="pagination"> {{ $users->links() }}


    </div>

@endsection